<?php

/**
 * See accept.php
 * The difference is that this page will only be requested from Billmate API and not visited by a human
 * Requests sent to this page might be for orders that already exists in store or new orders so make sure to be able to manage both scenarios
 */
