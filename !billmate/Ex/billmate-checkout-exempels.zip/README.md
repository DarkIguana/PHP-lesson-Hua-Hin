# Billmate Checkout Example
Codes in examples are not created to be used in production mode and are only examples of how to integrate and use Billmate Checkout.

Please note that many values are hardcoded and that is only for make the examples easier to write and read.

##Installation & Configuration
1. Duplicate config_sample.php and rename to config.php
2. Enter your API ID and Secret and other configs in the config gile file.
3. Run the index.php file from your browser. You should now see the Checkout window.